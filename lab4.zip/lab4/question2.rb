require 'erb'

def shopping_items
	['milk', 'egg', 'ham', 'bread']
end

class ShoppingList
	include ERB::Util
	attr_accessor :template, :shop_items, :date

	def initialize(shop_items, template, date=Time.now)
		@date = date
		@shop_items = shopping_items	
		@template = ""                  
		i = 0       
		File.open("#{template}", "r") do |file|   #copy template from external file shoppinglist.html.erb
			file.readlines.each do |line|
				@template += line
				i += 1
			end
		end
    	filter(@template)
		save('shoppinglistOutput2.html')       #output file 
	end

	def save(file)                   #saves information 
		File.open(file, "w+") do |f|
			f.write(render)
		end
	end

	def render()                 #transforms ruby code into actual representation     
		ERB.new(@template).result(binding)
	end

    def filter(input)                #add template html filter 
		template_str = ""
		(0..(input.length())).each do |a|
			template_str += input[a].to_s
		end
		output_html = File.new("shoppinglistOutput2.html", "w+")
		output_html.puts(template_str)
		output_html.close
	end

	def output(*arg)                                    #output file with template 
		File.open("#{arg[0]}", "r") do |file|
			file.readlines.each do |line|
				puts line
			end
		end
	end
end

list = ShoppingList.new(shopping_items, 'shoppinglist.html.erb')
list.output('shoppinglistOutput2.html')
