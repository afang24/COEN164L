require 'erb'

def shopping_items
	['milk', 'egg', 'ham', 'bread']
end

def template
	%{
		<html>
		<head>
		</head>
		<body>
		<h1> Shopping List for <%= @date.strftime('%A, %d, %B, %Y')%>
		<p> You need to buy </p>
		<ul>
			<%for item in @shop_items %>
				<li> <%= item %> </li>
			<% end %>
		</ul>
		</body>
		</html>
	}
end

class ShoppingList
	include ERB::Util
	attr_accessor :template, :shop_items, :date

	def initialize(shop_items, template, date=Time.now)

		@template = template
        @shop_items = shopping_items
        @date = date

		filter(@template)
		save('shoppinglistOutput1.html')			#output file
	end

	def save(file)								#saves information 
		File.open(file, "w+") do |f|
			f.write(render)
		end
	end

	def render()						#transforms ruby code into its actual representation 
		ERB.new(@template).result(binding)
	end

	def filter(input)							#add template html filter 
		template_str = ""
		(0..(input.length())).each do |a|
			template_str += input[a].to_s
		end
		output_html = File.new("shoppinglistOutput1.html", "w+")
		output_html.puts(template_str)
		output_html.close
	end

	def output(*arg)									#outputs file with template 
		File.open("#{arg[0]}", "r") do |file|	
			file.readlines.each do |line|
				puts line
			end
		end
	end
end

list = ShoppingList.new(shopping_items, template)
list.output('shoppinglistOutput1.html')
