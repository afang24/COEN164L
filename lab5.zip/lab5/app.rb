require 'sinatra'
require 'sinatra/reloader' 


=begin
class User 
    property :userName, Text
    property :accountBalance, Integar
    property :accountID, Serial
end
=end

#to initilize
configure do
    enable :sessions    #same as set session, true 

    set :name, "defaultname"
    set :accountID, "defaultaccountID"
    set :password, "defaultpassword"
    set :balance, "0"
end         #configure, enable and set are all methods in sinatra

=begin
#to retrieve 
settings.name 

#to reset 
settings.myname = "anothervalue" 
=end 


get '/' do 
    erb :homepage
end 

#-------------------------New Account Creation -----------------#

get '/openNewAccount' do    #sends blank form 
    @title = "New Account Creation:"
    #if session[:login]
        erb :openNewAccount    
   # end                  
end 

post '/login' do
    #"Username: #{params[:username]} <br> AccountID: #{params[:accountID]} <br> Account Balance is: #{settings.balance} "
    settings.name = params[:username]
    settings.accountID = params[:accountID]
    settings.password = params[:password]
    settings.balance = "0"
    redirect '/accountInfo'
end

#------------------------Account info--------------------#

get '/accountInfo' do                   #display account information 
    erb :accountInfo
end 

#-----------------------Deposit-----------------------#
get '/depositForm' do 
    @title = "You Chose Deposit Money into your Account:"
    erb :depositForm
end

post '/deposit' do
    if (params[:username] == settings.name) && (params[:accountID] == settings.accountID) && (params[:password] == settings.password)     #user is correct
        settings.balance = (params[:deposit].to_i + settings.balance.to_i).to_s
        redirect '/accountInfo'
    else    
        puts "Wrong Credentials cannot deposit money"
        redirect '/depositForm'
    end 
end

#------------------------Withdraw-----------------------#

get '/withdrawForm' do 
    @title = "You Chose Withdraw Money from your Account:"
    erb :withdrawForm
end

post '/withdraw' do
    if params[:username] == settings.name && params[:accountID] == settings.accountID && params[:password] == settings.password     #user is correct
        settings.balance = (settings.balance.to_i - params[:withdraw].to_i).to_s
        redirect '/accountInfo'
    else    
        puts "Wrong Credentials cannot withdraw money"
        redirect '/depositForm'
    end 
end


#------------------------edge cases----------------------#
not_found do
    "sorry don't know what to do"
end








